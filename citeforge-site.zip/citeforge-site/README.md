# CiteForge landing page (Genesis 2.0, PS-04)

Plain HTML + CSS + JavaScript. No build step, no dependencies.

Run: open `index.html` in a browser (or `npx serve .` / VS Code Live Server).
Deploy: drag this folder onto Netlify, or push to GitHub Pages / Cloudflare Pages.

- `index.html` : page structure and content
- `style.css`  : design tokens (colors in `:root`), layout, animations
- `script.js`  : live citation demo, before/after toggle, tabs, scroll reveal, counters

Demo numbers and answers are illustrative sample data, not real citation results.
